function CodeDefine() { 
this.def = new Array();
this.def["ert_main.c:rtM_"] = {file: "ert_main_c.html",line:23,type:"var"};
this.def["ert_main.c:rtMPtr"] = {file: "ert_main_c.html",line:24,type:"var"};
this.def["ert_main.c:rtDW"] = {file: "ert_main_c.html",line:25,type:"var"};
this.def["rt_OneStep"] = {file: "ert_main_c.html",line:39,type:"fcn"};
this.def["main"] = {file: "ert_main_c.html",line:76,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu_rtZBUS_TASK_PATH_OutParam"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:22,type:"var"};
this.def["BigEndianIEEEDouble"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:157,type:"type"};
this.def["LittleEndianIEEEDouble"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:164,type:"type"};
this.def["IEEESingle"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:171,type:"type"};
this.def["rtInf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:173,type:"var"};
this.def["rtMinusInf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:174,type:"var"};
this.def["rtNaN"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:175,type:"var"};
this.def["rtInfF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:176,type:"var"};
this.def["rtMinusInfF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:177,type:"var"};
this.def["rtNaNF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:178,type:"var"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetNaN"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:188,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetNaNF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:212,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rt_InitInfAndNaN"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:224,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtIsInf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:236,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtIsInfF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:242,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtIsNaN"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:248,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtIsNaNF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:270,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetInf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:282,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetInfF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:306,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetMinusInf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:317,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rtGetMinusInfF"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:341,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:from_euler"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:349,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rotation_matrix"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:376,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:from_rotation_matrix"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:408,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:set_throttle_out"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:440,type:"fcn"};
this.def["rt_atan2d_snf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:523,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:wrap_PI"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:560,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:sqrt_controller"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:596,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:norm"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:641,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:ang_vel_limit"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:671,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:norm_p"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:730,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:from_axis_angle"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:770,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:quatmultiply"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:788,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:to_axis_angle"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:797,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:normalizeq"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:816,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:attitude_controller_run_quat"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:872,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:input_euler_angle_roll_pitch__j"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1137,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:rate_controller_run"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1315,type:"fcn"};
this.def["rt_remd_snf"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1435,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:AP_MotorsMulticopter_output"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1458,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:set_alt_target_from_climb_rate_"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1864,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_z_controller"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:1920,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:get_weathervane_yaw_rate_cds"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2088,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:run_xy_controller"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2124,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_vel_controller_xy"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2350,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:calc_nav_roll"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2391,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:stabilize"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2458,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:output_to_motors_plane"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2782,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_50hz"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2879,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_pitch_throttle"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:2894,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:get_bearing_to"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3244,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_waypoint"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3264,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:update_loiter"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3449,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:copter_run"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3573,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:get_vector_xy_from_origin_NE"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3599,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:plane_run"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3613,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:calc_nav_pitch"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3636,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:get_distance_NE"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3651,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:auto_mode"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:3665,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu.c:auto_mode_sl"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:4067,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu_step"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:4506,type:"fcn"};
this.def["input_euler_angle_roll_pitch_eu_initialize"] = {file: "input_euler_angle_roll_pitch_eu_c.html",line:4852,type:"fcn"};
this.def["RT_MODEL"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:40,type:"type"};
this.def["Bus_wp"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:49,type:"type"};
this.def["ENUM_FlightTaskMode"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:76,type:"type"};
this.def["ENUM_UAVMode"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:89,type:"type"};
this.def["ENUM_FlightControlMode"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:108,type:"type"};
this.def["ENUM_ControlMode"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:120,type:"type"};
this.def["ENUM_ComStatus"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:130,type:"type"};
this.def["ENUM_Where"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:142,type:"type"};
this.def["ENUM_AutoModeType"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:158,type:"type"};
this.def["BUS_TASK_PATH_OutParam"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:188,type:"type"};
this.def["struct_DPNgsN7egsyk8b07Zx1OdH"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:204,type:"type"};
this.def["DW"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:606,type:"type"};
this.def["ConstP"] = {file: "input_euler_angle_roll_pitch_eu_h.html",line:619,type:"type"};
this.def["rtConstP"] = {file: "input_euler_angle_roll_pitch_eu_data_c.html",line:21,type:"var"};
this.def["int8_T"] = {file: "rtwtypes_h.html",line:49,type:"type"};
this.def["uint8_T"] = {file: "rtwtypes_h.html",line:50,type:"type"};
this.def["int16_T"] = {file: "rtwtypes_h.html",line:51,type:"type"};
this.def["uint16_T"] = {file: "rtwtypes_h.html",line:52,type:"type"};
this.def["int32_T"] = {file: "rtwtypes_h.html",line:53,type:"type"};
this.def["uint32_T"] = {file: "rtwtypes_h.html",line:54,type:"type"};
this.def["int64_T"] = {file: "rtwtypes_h.html",line:55,type:"type"};
this.def["uint64_T"] = {file: "rtwtypes_h.html",line:56,type:"type"};
this.def["real32_T"] = {file: "rtwtypes_h.html",line:57,type:"type"};
this.def["real64_T"] = {file: "rtwtypes_h.html",line:58,type:"type"};
this.def["real_T"] = {file: "rtwtypes_h.html",line:64,type:"type"};
this.def["time_T"] = {file: "rtwtypes_h.html",line:65,type:"type"};
this.def["boolean_T"] = {file: "rtwtypes_h.html",line:66,type:"type"};
this.def["int_T"] = {file: "rtwtypes_h.html",line:67,type:"type"};
this.def["uint_T"] = {file: "rtwtypes_h.html",line:68,type:"type"};
this.def["ulong_T"] = {file: "rtwtypes_h.html",line:69,type:"type"};
this.def["ulonglong_T"] = {file: "rtwtypes_h.html",line:70,type:"type"};
this.def["char_T"] = {file: "rtwtypes_h.html",line:71,type:"type"};
this.def["uchar_T"] = {file: "rtwtypes_h.html",line:72,type:"type"};
this.def["byte_T"] = {file: "rtwtypes_h.html",line:73,type:"type"};
this.def["pointer_T"] = {file: "rtwtypes_h.html",line:94,type:"type"};
}
CodeDefine.instance = new CodeDefine();
var testHarnessInfo = {OwnerFileName: "", HarnessOwner: "", HarnessName: "", IsTestHarness: "0"};
var relPathToBuildDir = "../ert_main.c";
var fileSep = "\\";
var isPC = true;
function Html2SrcLink() {
	this.html2SrcPath = new Array;
	this.html2Root = new Array;
	this.html2SrcPath["ert_main_c.html"] = "../ert_main.c";
	this.html2Root["ert_main_c.html"] = "ert_main_c.html";
	this.html2SrcPath["input_euler_angle_roll_pitch_eu_c.html"] = "../input_euler_angle_roll_pitch_eu.c";
	this.html2Root["input_euler_angle_roll_pitch_eu_c.html"] = "input_euler_angle_roll_pitch_eu_c.html";
	this.html2SrcPath["input_euler_angle_roll_pitch_eu_h.html"] = "../input_euler_angle_roll_pitch_eu.h";
	this.html2Root["input_euler_angle_roll_pitch_eu_h.html"] = "input_euler_angle_roll_pitch_eu_h.html";
	this.html2SrcPath["input_euler_angle_roll_pitch_eu_data_c.html"] = "../input_euler_angle_roll_pitch_eu_data.c";
	this.html2Root["input_euler_angle_roll_pitch_eu_data_c.html"] = "input_euler_angle_roll_pitch_eu_data_c.html";
	this.html2SrcPath["rtwtypes_h.html"] = "../rtwtypes.h";
	this.html2Root["rtwtypes_h.html"] = "rtwtypes_h.html";
	this.getLink2Src = function (htmlFileName) {
		 if (this.html2SrcPath[htmlFileName])
			 return this.html2SrcPath[htmlFileName];
		 else
			 return null;
	}
	this.getLinkFromRoot = function (htmlFileName) {
		 if (this.html2Root[htmlFileName])
			 return this.html2Root[htmlFileName];
		 else
			 return null;
	}
}
Html2SrcLink.instance = new Html2SrcLink();
var fileList = [
"ert_main_c.html","input_euler_angle_roll_pitch_eu_c.html","input_euler_angle_roll_pitch_eu_h.html","input_euler_angle_roll_pitch_eu_data_c.html","rtwtypes_h.html"];
